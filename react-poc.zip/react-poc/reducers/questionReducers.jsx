export default (state = [], action) => {
  switch (action.type){
    // Check if action dispatched is
    // CREATE_BOOK and act on that
    case 'CREATE_QUESTION':
        return [
          ...state,
          Object.assign({},{ 
		  id: action.id,
			title: action.question.title,
			category: action.question.category})
        ];
    default:
          return state;
  }
};