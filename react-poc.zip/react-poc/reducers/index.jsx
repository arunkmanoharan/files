import { combineReducers } from 'redux';
import questions from './questionReducers.jsx'

const rootReducer = combineReducers({  questions: questions,
  // More reducers if there are
  // can go here
});

export default rootReducer;