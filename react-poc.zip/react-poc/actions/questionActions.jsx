let nextQuestion = 0
export const createQuestion = (question) => {
  // Return action
  return {
    // Unique identifier
    type: 'CREATE_QUESTION',
	id: nextQuestion++,
    // Payload
    question
  }
};