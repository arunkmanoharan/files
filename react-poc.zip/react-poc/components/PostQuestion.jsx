// ./src/components/book/BookPage.js
import React from 'react';
import { connect } from 'react-redux';
import * as questionActions from '../actions/questionActions.jsx';
import {browserHistory} from 'react-router'

class PostQuestions extends React.Component{
  constructor(props){
    // Pass props back to parent
    super(props);
  }

  // Submit book handler
  submitQuestion(input){
  console.log(input);
    this.props.createQuestion(input);
	browserHistory.push('/questions');
  }

  render(){
    // Title input tracker
    let titleInput, categoryInput;
    // return JSX
    return(
      <div>
          <h3>Ask Question</h3>
          <form onSubmit={e => {
            // Prevent request
            e.preventDefault();
            // Assemble inputs
			if(titleInput.value == '' || categoryInput.value == '') {
				return false;
			}
            var input = {title: titleInput.value, category: categoryInput.value};
            // Call handler
            this.submitQuestion(input);
            // Reset form
            e.target.reset();
          }}>
            <label>Question:</label><input type="text" name="title" ref={node => titleInput = node}/><br/><br/>
			<label>Category:</label><input type="text" name="category" ref={node => categoryInput = node}/><br/><br/>
            <input type="submit" />
          </form>
      </div>
    )
  }
}



// Maps state from store to props
const mapStateToProps = (state, ownProps) => {
  return {
    // You can now say this.props.books
    questions: state.questions
  }
};

// Maps actions to props
const mapDispatchToProps = (dispatch) => {
  return {
  // You can now say this.props.createBook
    createQuestion: question => dispatch(questionActions.createQuestion(question))
  }
};

// Use connect to put them together
export default connect(mapStateToProps, mapDispatchToProps)(PostQuestions);