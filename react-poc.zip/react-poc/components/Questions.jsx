// ./src/components/book/BookPage.js
import React, {PropTypes} from 'react';
import { connect } from 'react-redux';

class Questions extends React.Component{

  render(){
  console.log(this.props);
    // return JSX
    return(
      <div>
        <h3>Questions</h3>
        
          {/* Traverse books array  */}
          {this.props.questions.map((b, i) => 
				<p>
					{i}.
					<b> {b.title}</b>
					<a href="/q-view/{b.id}">   {b.category}</a> 
				</p>)
		   }
        
      </div>
    )
  }
}


const mapStateToProps = (state, ownProps) => {
  return {
     // You can now say this.props.books
    questions: state.questions
  }
};

// Use connect to put them together
export default connect(mapStateToProps)(Questions);
