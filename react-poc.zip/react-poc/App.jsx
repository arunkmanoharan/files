import React  from 'react';
import {Link} from 'react-router';

const App = (props) => {
  return (
    <div>
		<div>
         <p><a className="navbar-brand" href="#"><h1>Q&A</h1></a></p>
              <h2><Link to="/">  Home</Link></h2>
              <h2><Link to="/about">  About</Link></h2>
              <h2><Link to="/questions">  Questions</Link></h2>
              <h2><Link to="/post-question">  Ask Question</Link></h2>
		</div>
      {/* Each smaller components */}
      {props.children}
    </div>
  );
};

export default App