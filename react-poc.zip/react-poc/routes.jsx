import React  from 'react';
import {Route, IndexRoute} from 'react-router';
import Questions from './components/Questions.jsx'
import About from './components/About.jsx'
import PostQuestion from './components/PostQuestion.jsx'
import App from './App.jsx'

export default (
  <Route path="/" component={App}>
    <IndexRoute component={Questions}></IndexRoute>
    <Route path="/about" component={About}></Route>
    <Route path="/questions" component={Questions}></Route>
	<Route path="/post-question" component={PostQuestion}></Route>
  </Route>
);