"use strict";

/* -------------------------------------------------------
                     Radar Grid Stuff
------------------------------------------------------- */
var radarWidth = $('#radar').width(),
	canvas = document.getElementById('radar-grid'),
	ctx = canvas.getContext('2d');

$(canvas).attr({
	'width' : radarWidth,
	'height' : radarWidth
});

ctx.strokeStyle = '#e2a82d';
ctx.lineWidth = 1;

var radarRadius = radarWidth/2,
	outerCircleRadius = radarRadius - 4,
	midCircleRadius = radarRadius - radarRadius/3,
	innerCircleRadius = radarRadius/4;

// grid lines
drawLineBwtweenCircles(radarRadius, radarRadius, innerCircleRadius, outerCircleRadius);
ctx.save();
ctx.translate(radarRadius, radarRadius);
ctx.rotate(45*Math.PI/180);
drawLineBwtweenCircles(0, 0, innerCircleRadius, outerCircleRadius);
ctx.restore();

// inner circle
drawSolidCircle(radarRadius, radarRadius, innerCircleRadius, 3);
drawDottedCircle(radarRadius, radarRadius, innerCircleRadius, 8, 2, "#1E1E20");

// mid circle
drawSolidCircle(radarRadius, radarRadius, midCircleRadius, 3);
drawDottedCircle(radarRadius, radarRadius, midCircleRadius, 16, 2, "#1E1E20");
ctx.save(); // create save-point
ctx.translate(radarRadius, radarRadius);
ctx.rotate(45*Math.PI/180);
drawDottedCircle(0, 0, midCircleRadius-15, 4);
ctx.restore(); // restore save-point

// outer circle
drawSolidCircle(radarRadius, radarRadius, outerCircleRadius, 1);
drawDottedCircle(radarRadius, radarRadius, outerCircleRadius-10, 4);


function drawLineBwtweenCircles(centerX, centerY, smallRadius, largeRadius, lineWidth) {
	ctx.beginPath();
	ctx.lineWidth = lineWidth || 1;

	// vertical top line
	ctx.moveTo(centerX+0.5, centerY-smallRadius);
	ctx.lineTo(centerX+0.5, centerY-largeRadius);
	ctx.stroke();

	// vertical bottom line
	ctx.moveTo(centerX+0.5, centerY+smallRadius);
	ctx.lineTo(centerX+0.5, centerY+largeRadius);
	ctx.stroke();

	// horizontal right line
	ctx.moveTo(centerX+smallRadius, centerY+0.5);
	ctx.lineTo(centerX+largeRadius, centerY+0.5);
	ctx.stroke();

	// horizontal left line
	ctx.moveTo(centerX-smallRadius, centerY+0.5);
	ctx.lineTo(centerX-largeRadius, centerY+0.5);
	ctx.stroke();
}

function drawSolidCircle(centerX, centerY, radius, lineWidth) {
	ctx.beginPath();
	ctx.lineWidth = lineWidth || 1;
	ctx.arc(centerX, centerX, radius, 0, 2*Math.PI);
	ctx.closePath();
	ctx.stroke();	
}

function drawDottedCircle(centerX, centerY, radius, dashCount, dashWidth, dashColor) {
	var angleGap = 360 / (dashCount * 2), // in degree
		startPoint = -Math.PI*(angleGap/2)/180, // converted to radian start point
		endPoint = -startPoint, // radian end point
		gapSize = Math.PI*(angleGap*2)/180,
		dashWidth = dashWidth || 1;

	for (var i=0; i<dashCount; i++) {
		ctx.beginPath();
		ctx.lineWidth = dashWidth;
		ctx.strokeStyle = dashColor || "#e2a82d";
		ctx.arc(centerX, centerY, radius, startPoint, endPoint);
		ctx.stroke();

		startPoint = startPoint + gapSize;
		endPoint = endPoint + gapSize;
	}

	ctx.strokeStyle = '#e2a82d'; // reset the stroke color back
}

/* -------------------------------------------------------
                    Full Screen Page (BAD)
------------------------------------------------------- */
(function adjustElementHeights() {
	var x = 0;

	$('#title-bar, #message-box, #navigation-bar').each(function() {
		x += $(this).outerHeight();
	});

	var mainContent = $('#main-content'),
		iniHeight = mainContent.outerHeight(),
		windowHeight = $(window).outerHeight(),
		extendedHeight = windowHeight - x;

	if (x + iniHeight <= windowHeight) {
		mainContent.css({
			'height' : extendedHeight+'px',
			'padding' : (extendedHeight - iniHeight)/2+'px 0'
		});
	};
})();


/* -------------------------------------------------------
                       Radar Data
------------------------------------------------------- */
// WARNING :: If more than 3 elements are in any quadrant,
// adjust/remove the offset accordingly.

var data = {
		'q1' : ['Where'],
		'q2' : ['Diet'],
		'q3' : ['Age'],
		'q4' : ['History']
	},
	offsetAngle = 15, // degree
	offsetRadius = 20, // px
	dotDiameter = $('#dots-wrap .dot:eq(0)').width(),
	usableRadius = $('.radar-circle.main').width() / 2 - dotDiameter - offsetRadius,
	animationDuration = 8,
	dotCountList = countDots(data), // dot count in each quadrants
	generatedData = [],
	dotsWrap = $('#dots-wrap');

// console.log('Dot Count In Quadrants: ' + dotCountList);

// Set radar hand animation in motion
$('.radar-hand').css('animation-duration', animationDuration+'s');

// Generate random dot data & populate dot
for (var i=0; i<dotCountList.length; i++) {
	generatedData[i] = [];

	var startAngle, endAngle;
	// set start and end for random angle generation	
	if (i==0) {
		startAngle = 0 + offsetAngle;
		endAngle = 90 - offsetAngle;
	}
	else if (i==1) {
		startAngle = 90 + offsetAngle;
		endAngle = 180 - offsetAngle;
	}
	else if (i==2) {
		startAngle = 180 + offsetAngle;
		endAngle = 270 - offsetAngle;
	}
	else if (i==3) {
		startAngle = 270 + offsetAngle;
		endAngle = 360 - offsetAngle;
	}

	// console.log('Start: '+startAngle+' End: '+endAngle);

	for (var j=0; j<dotCountList[i]; j++) {
		var randRadius, randAngle, pass = false;
		
		randAngle = generateRandomNumberBetween(startAngle, endAngle);
		if (generatedData[i].length ==0) {
			randRadius = generateRandomNumberBetween(offsetRadius, usableRadius);
		}		

		// check if the randRadius passes the test (radius should be offsetRadius apart)
		while (pass == false && generatedData[i].length > 0) {
			randRadius = generateRandomNumberBetween(offsetRadius, usableRadius);
			// console.log('Generated Random Radius: '+randRadius);

			for (var k=0; k<generatedData[i].length; k++) {
				// console.log('Radius From List: '+generatedData[i][k][0]);

				if (Math.abs(randRadius-generatedData[i][k][0]) > offsetRadius) {
					// console.log('Criteria Passed');
					pass = true;
				}
				else {
					// console.log('Criteria Failed');
					pass = false;
					break;
				}
			}
		}
		
		generatedData[i].push([randRadius, randAngle]);

		// Populate DOM with dots
		var dotData = data['q'+(i+1)][j]; // considering key of main data in 'q1,q2..' format
		populateDot([randRadius, randAngle], dotData);
	}

	console.log('Q'+(i+1)+': '+generatedData[i]);
}

// console.log('Generated Data: '+generatedData);

function countDots(object) {
	var list = [0, 0, 0, 0];

	for (var i in object) {
		// considering last character of key represents quadrant number
		list[i.slice(-1)-1] = object[i].length;
	}

	return list;
}

function generateRandomNumberBetween(num1, num2) {
	var max = num1 > num2 ? num1 : num2,
		min = num1 < num2 ? num1 : num2;

	// console.log('Max: '+max+' <br> Min: '+min);

	return Math.floor(min + Math.random()*(max-min+1));
}

function calculateCoordinate(list) { // takes a list [radius,angle] as input
	var hypotenuse = list[0],
		angle = list[1],
		quadrant, x, y;

	if (angle < 90) {
		quadrant=1;
	}
	else if (angle<180 && angle>90) {
		quadrant=2;
		angle = 180 - angle;
	}
	else if (angle<270 && angle>180) {
		quadrant=3;
		angle = angle - 180;
	}
	else if (angle<360 && angle>270) {
		quadrant=4;
		angle = 360 - angle;
	}

	x = Math.floor(Math.cos(Math.PI*angle/180) * hypotenuse);
	y = Math.floor(Math.sqrt(Math.pow(hypotenuse,2) - Math.pow(x,2)));

	if (quadrant == 2) {
		x = -(x+dotDiameter);
	}
	else if (quadrant == 3) {
		x = -(x+dotDiameter);
		y = -(y+dotDiameter);
	}
	else if (quadrant == 4) {
		y = -(y+dotDiameter);
	}

	return [x, y];
}

function populateDot(list, dotData) { // takes a list [radius,angle] & Dot text as input	
	var coordinate = calculateCoordinate(list),
		dotItem = $('<div class="dot-item"><div class="dot-icon"></div><div class="dot-text"></div></div>'),
		x = coordinate[0], y = coordinate[1],
		quadrant, delayAngle;

	if (x>0 && y>0) { quadrant = 1; }
	else if (x<0 && y>0) { quadrant = 2; }
	else if (x<0 && y<0) { quadrant = 3; }
	else if (x>0 && y<0) { quadrant = 4; }

	if (list[1] < 90) {
		delayAngle = 90-list[1];
	}
	else {
		delayAngle = 90 + (360-list[1]);
	}

	dotItem.addClass('q'+quadrant+'-item').css({
		'left' : coordinate[0],
		'bottom' : coordinate[1]
	}).children().css({
		'animationDuration' : animationDuration+'s',
		'animation-delay' : animationDuration*delayAngle/360 + 's'
	}).last('.dot-text').text(dotData);

	dotsWrap.append(dotItem);
}
