<?php

if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


function qa_users_sub_nimeyo_navigation()
/*
	Return the sub navigation structure for user listing pages
*/
	{
		if ((!QA_FINAL_EXTERNAL_USERS) && (qa_get_logged_in_level()>=QA_USER_LEVEL_MODERATOR)) {
			return array(
				'users/active' => array(
					'url' => qa_path_html('users/active'),
					'label' => 'ACTIVE',
				),
				'users/blocked' => array(
					'label' => 'INACTIVE',
					'url' => qa_path_html('users/blocked'),
				),
			);

		} else
			return null;
	}
	
	
	function qa_tags_sub_nimeyo_navigation()
/*
	Return the sub navigation structure for user listing pages
*/
	{
			return array(
				'tags/recent' => array(
					'url' => qa_path_html('tags/recent'),
					'label' => 'RECENT',
				),

				'tags/hot' => array(
					'label' => 'HOT',
					'url' => qa_path_html('tags/hot'),
				),

				'tags/name' => array(
					'label' => 'NAME',
					'url' => qa_path_html('tags/name')
				),
			);
	}
	
	function qa_db_popular1_tags_selectspec($start, $count=null, $sort=null, $filter=null)
/*
	Return the selectspec to retrieve the most popular tags. Return $count (if null, a default is used) tags, starting
	from offset $start. The selectspec will produce a sorted array with tags in the key, and counts in the values.
*/
	{
		switch ($sort) {
			case 'recent':
				$selectsort='sortdesc';
				$value =  'wordid';
				break;

			
			case 'name':
				$selectsort='sortasc';
				$value =  'word';
				break;
				
			case 'hot':
				$selectsort='sortdesc';
				$value =  'tagcount';
				break;

			default:
				$selectsort='sortdesc';
				$value =  'tagcount';
				break;
		}
		
		$where = '';
		if($filter) {
			$where = 'word LIKE "%'.$filter.'%" AND';
		}
			
			$count=isset($count) ? $count : QA_DB_RETRIEVE_TAGS;

			return array(
				'columns' => array('word', 'tagcount', 'wordid'),
				'source' => '^words WHERE '.$where.' tagcount>0 ORDER BY tagcount ASC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'word',
				'arrayvalue' => 'tagcount',
				$selectsort => $value,
				//'sortasc' => $sort?$sort:'word',
			);
	}
	

	function qa_db_active_users_selectspec($start, $count=null, $filter=null)
/*
	Return the selectspec to get the active users, with handles if we're using internal user management. Return
	$count (if null, a default is used) users starting from the offset $start.
*/
	{
		$count=isset($count) ? min($count, QA_DB_RETRIEVE_USERS) : QA_DB_RETRIEVE_USERS;
		$where ='';
		if($filter) {
			$where = 'handle LIKE "%'.$filter.'%" AND';
		}
		if (QA_FINAL_EXTERNAL_USERS)
			return array(
				'columns' => array('userid', 'points'),
				'source' => '^userpoints ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);

		else
			return array(
				'columns' => array('^users.userid', 'handle', 'points', 'flags', '^users.email', 'avatarblobid' => 'BINARY avatarblobid', 'avatarwidth', 'avatarheight', 'loggedin'),
				'source' => '^users JOIN ^userpoints ON ^users.userid=^userpoints.userid WHERE '.$where.' ^users.flags="0" ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);
	}
	
	function qa_db_inactive_users_selectspec($start, $count=null, $filter=null)
/*
	Return the selectspec to get the active users, with handles if we're using internal user management. Return
	$count (if null, a default is used) users starting from the offset $start.
*/
	{
		$count=isset($count) ? min($count, QA_DB_RETRIEVE_USERS) : QA_DB_RETRIEVE_USERS;
		$where ='';
		if($filter) {
			$where = 'handle LIKE "%'.$filter.'%" AND';
		}
		if (QA_FINAL_EXTERNAL_USERS)
			return array(
				'columns' => array('userid', 'points'),
				'source' => '^userpoints ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);

		else
			return array(
				'columns' => array('^users.userid', 'handle', 'points', 'flags', '^users.email', 'avatarblobid' => 'BINARY avatarblobid', 'avatarwidth', 'avatarheight','loggedin'),
				'source' => '^users JOIN ^userpoints ON ^users.userid=^userpoints.userid WHERE '.$where.' ^users.flags!="0" ORDER BY points DESC LIMIT #,#',
				'arguments' => array($start, $count),
				'arraykey' => 'userid',
				'sortdesc' => 'points',
			);
	}

