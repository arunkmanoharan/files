$(document).ready(function(){ // when the document is loaded completely

	if ($.cookie('alreadythere')) {
		$('.blue-banner ').toggleClass('shrink');
		$('.tags-page').toggleClass('shrink');
	} else {
		$.cookie('alreadythere', 'yes');
	}
	
	
	$('#shrink-banner').on('click',function(){
		$('.blue-banner').toggleClass('shrink');
	});

	$('.browse-file .browse-btn, .browse-file .text-input').click(function () {
		$('.browse-file .file-input').click();
		
	});

	$('.browse-file .file-input').change(function(){
		console.log($('.browse-file .file-input').val().split('C:\\fakepath\\')[1]);
		$('.browse-file .text-input').val($('.browse-file .file-input').val().split('C:\\fakepath\\')[1]);
	});

	$('.as-select .select-default').on('click',function(){
		$(this).siblings('ul.option').toggle();
	});

	$('.blue-header.tags-page .arrow a').on('click',function(){
		$('.blue-header.tags-page').toggleClass('shrink');
	});

});

	function qa_vote_click(elem)
	{
		//alert();
		var ens=elem.name.split('_');
		var postid=ens[1];
		var vote=parseInt(ens[2]);
		var code=elem.form.elements.code_vote.value;
		var anchor=ens[3];

		//console.log(code);
		qa_ajax_post('vote', {postid:postid, vote:vote, code:code},
			function(lines) {
				
				//console.log(lines.slice(1).join("\n"));
				if (lines[0]=='1') {
					
					//qa_set_inner_html(document.getElementById('voting_'+postid), 'voting', lines.slice(1).join("\n"));
					var step_n = $('#voting_'+postid+ ' li.vote').index();
					//console.log(step_n);
					$('#voting_'+postid+ ' li.vote').remove('');
					if($('#voting_'+postid+ ' li').length > 0) {
						$('#voting_'+postid+' li:eq('+step_n+')').before(lines.slice(1).join("\n"));
					} else {
						qa_set_inner_html(document.getElementById('voting_'+postid), 'voting', lines.slice(1).join("\n"));
					}
						

				} else if (lines[0]=='0') {
					var mess=document.getElementById('errorbox');

					if (!mess) {
						var mess=document.createElement('div');
						mess.id='errorbox';
						mess.className='qa-error';
						mess.innerHTML=lines[1];
						mess.style.display='none';
					}

					var postelem=document.getElementById(anchor);
				//console.log(postelem);
					var e=postelem.parentNode.insertBefore(mess, postelem);
					qa_reveal(e);

				} else
					qa_ajax_error();
			}
		);

		return false;
	}
