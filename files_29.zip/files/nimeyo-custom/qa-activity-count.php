<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-include/qa-widget-activity-count.php
	Description: Widget module class for activity count plugin


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
*/

class qa_nimeyo_activity_count
{
	public function allow_template($template)
	{
		return true;
	}

	public function allow_region($region)
	{
		return ($region=='side');
	}

	public function output_widget($region, $place, $themeobject, $template, $request, $qa_content)
	{
		$themeobject->output('<div class="heading">all activity count</div>
								<div class="content">
									<ul class = "activity-list">');									

			$this->output_count($themeobject, qa_opt('cache_qcount'), 'QUESTION', 'QUESTIONS');
			$this->output_count($themeobject, qa_opt('cache_acount'), 'ANSWER', 'ANSWERS');

			if (qa_opt('comment_on_qs') || qa_opt('comment_on_as'))
				$this->output_count($themeobject, qa_opt('cache_ccount'), 'COMMENT', 'COMMENTS');

			$this->output_count($themeobject, qa_opt('cache_userpointscount'), 'USER', 'USERS');

		$themeobject->output('</ul>
								</div>
									</div>');
	}

	public function output_count($themeobject, $value, $langsingular, $langplural)
	{
		$themeobject->output('<li class = "border">');

		if ($value==1)
			$themeobject->output('<span class = "count">'.$value.'</span><span class = "text">'.$langsingular.'</span>');
		else
			$themeobject->output('<span class = "count">'.$value.'</span><span class = "text">'.$langplural.'</span>');

		$themeobject->output('</li>');
	}
}
