'use strict';


/*--------------------------------------------------------------------------
                                  Carousel
--------------------------------------------------------------------------*/
// Initialize Carousel
var carouselList = $('.carousel'),
	slideDuration = 600, // Same as transition duration
	lastIndicatorClick;

carouselList.each(function() {

	// Adding handlers to carousel indicators
	if ($(this).children('.carousel-indicator-wrap').length > 0) {
		var activeItemIndex = $(this).children('.carousel-item.active').index();

		// Add 'active' class to indicator
		$(this).find('.carousel-indicator').eq(activeItemIndex).addClass('active');
		$(this).find('.carousel-indicator').click(function() {
			if (processCarouselClick()) {
				slideToItem($(this).closest('.carousel').children('.carousel-item').eq($(this).index()));
			}
		});
	}

	// Adding handlers to carousel controls
	if ($(this).children('.carousel-control-wrap').length > 0) {
		$(this).find('.carousel-control').click(function() {
			if (processCarouselClick()) {
				var activeItem = $(this).closest('.carousel').children('.carousel-item.active'),
					nextItem = activeItem.next(),
					prevItem = activeItem.prev(),
					goToItem;

				if ($(this).hasClass('next')) {
					goToItem = nextItem.hasClass('carousel-item') ? nextItem : activeItem.siblings().eq(0);
				}
				else {
					goToItem = prevItem.hasClass('carousel-item') ? prevItem : activeItem.siblings('.carousel-item').last();
				}

				slideToItem(goToItem);
			}
		});
	}
});

// Validates the click event
function processCarouselClick() {
	var currentIndicatorClick = new Date().getTime(),
		clickStatus = false;

	if (lastIndicatorClick == null || currentIndicatorClick-lastIndicatorClick > slideDuration) {
		clickStatus = true;
		lastIndicatorClick = currentIndicatorClick;
	}

	return clickStatus;
}

// Slides to the successive item
function slideToItem(successiveItem) {
	var carousel = successiveItem.closest('.carousel'),
		activeItem = carousel.find('.carousel-item.active'),
		activeItemIndex = activeItem.index(),
		successiveItemIndex = successiveItem.index();

	// Slide left
	if (activeItemIndex < successiveItemIndex) {
		successiveItem.addClass('next');
		// Delay between class changes
		setTimeout(function() {
			activeItem.add(successiveItem).addClass('left');
		}, 30);

		setTimeout(function() {
			activeItem.removeClass('active left');
			successiveItem.removeClass('next left').addClass('active');
		}, slideDuration);
	}
	// Slide right
	else if ( activeItemIndex > successiveItemIndex) {
		successiveItem.addClass('prev');
		// Delay between class changes
		setTimeout(function() {
			activeItem.add(successiveItem).addClass('right');
		}, 30);

		setTimeout(function() {
			activeItem.removeClass('active right');
			successiveItem.removeClass('prev right').addClass('active');
		}, slideDuration);
	}

	// Update carousel indicator
	carousel.find('.carousel-indicator').eq(successiveItemIndex).addClass('active').siblings().removeClass('active');
}


/*--------------------------------------------------------------------------
                               Block Highlight
--------------------------------------------------------------------------*/
$('#enterprise-info, #enterprise-benefits').find('.block-content').on( 'mouseenter', function() {
	$(this).addClass('highlight-content').siblings().removeClass('highlight-content');
});

/*--------------------------------------------------------------------------
                               Overlay Menu
--------------------------------------------------------------------------*/
var overlayMenu = $('.overlay-menu');

overlayMenu.children('.menu-close').add('header.header .ham-logo').click(function() {
	overlayMenu.toggleClass('show-menu');
});


/*--------------------------------------------------------------------------
                              Job Description
--------------------------------------------------------------------------*/
$('.job-role .button').click(function() {
	var text = $(this).text().toUpperCase() == 'MORE' ? 'LESS' : 'MORE';

	$(this).parent().find('.job-info').slideToggle();
	
	$(this).text(text).toggleClass('expanded-button');
});

/*--------------------------------------------------------------------------
                                  Accordion
--------------------------------------------------------------------------*/
$('.accordion .accordion-title').click(function() {
	$(this).parent().siblings('.accordion').removeClass('accordion-expanded').children('.accordion-content').slideUp();
	$(this).siblings('.accordion-content').slideToggle().parent().toggleClass('accordion-expanded');
});

/*--------------------------------------------------------------------------
                                	Modal
--------------------------------------------------------------------------*/
var modal = $('.modal-glass');

$('[data-modal]').click(function() {
	var modalData = $('[data-modal-content="'+$(this).attr('data-modal')+'"]');

	if (modalData.length > 0) {
		modal.find('.modal-heading-text').text(modalData.find('[data-modal-heading]').text());
		modal.find('.modal-body').html(modalData.find('[data-modal-body]').html());

		modal.removeClass('hide');
		setTimeout(function() {
			modal.children('.modal').addClass('show-modal');
		}, 50);
	}
});

modal.find('.modal-close').click(function() {
	modal.addClass('hide').children('.modal').removeClass('show-modal');
	modal.find('.modal-heading-text').empty();
	modal.find('.modal-body').empty();
});


/*--------------------------------------------------------------------------
                                  Dropdown
--------------------------------------------------------------------------*/
$('.dropdown').click(function() {
	var dropdown = this;
	// collapse other dropdowns
	$('.dropdown').each(function() {
		if (this != dropdown) {
			$(this).removeClass('.dropdown-open').find('.dropdown-options').addClass('hide');
		}
	});

	$(this).find('.dropdown-options').toggleClass('hide').parent('.dropdown').toggleClass('dropdown-open');
});

$('.dropdown-options li').click(function() {
	$(this).parent().siblings('.selected-option').text($(this).text());
});

/*--------------------------------------------------------------------------
                                Sticky Menu
--------------------------------------------------------------------------*/
$(window).scroll(function() {
	if ($(window).scrollTop() > 15) {
		$('header.header').addClass('sticky-header');
	}
	else {
		$('header.header').removeClass('sticky-header');
	}
});

/*--------------------------------------------------------------------------
                              Fancy Animation
--------------------------------------------------------------------------*/
var fadeElements = $('[data-fadein]');

// $(window).scroll(function() {
// 	fadeElements.each(function() {
// 		var bottomOfElement = $(this).offset().top + $(this).outerHeight(),
// 			bottomOfWindow = $(window).scrollTop() + $(window).height();

// 		if (bottomOfWindow > bottomOfElement) {
// 			console.log('Will unhide');
// 		}
// 	});
// });


/*--------------------------------------------------------------------------
                              Temporary Garbage
           WARNING :: Delete the following if you are in Milky Way
--------------------------------------------------------------------------*/
if (window.location.href.endsWith('blog.html')) {
	$('.post-tile, .post-carousel .open-blog-post').click(function() {
		location.assign('blog-two.html');
	});
}
