<!DOCTYPE html>
<html>
	<head>
		<title>Confirmation Email</title>
	</head>
	<body>
		<h1>Thank you for signup</h1>
		<p>
			You need to <a href='{{ url("register/confirm/{$user->token}")}}'>Confirm your email address</a>
		</p>
	</body>
</html>