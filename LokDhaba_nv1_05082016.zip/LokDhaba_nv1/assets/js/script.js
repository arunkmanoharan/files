$(document).ready(function(){ // when the document is loaded completely

	// to hide/ show the related link part in mobile view
	$('.visible-xs .link-box h5').on('click',function(){
		$(this).siblings('p').slideToggle(550);
		$(this).children('span').children('img').toggleClass('rotate');
	});

	// previous button should be disabled initially
	$('.prev').addClass('disabled');


	$('body').on('click','.prev, .next',function(){
		if(angular.element('#questionCtrl').scope().current>0 && angular.element('#questionCtrl').scope().current<14){
			$('.questions').hide().fadeIn(100); // for the fade effect on moving from one question to another
			$('.prev').removeClass('disabled');
			$('.next').removeClass('disabled');
		}
		else{
			if(angular.element('#questionCtrl').scope().current<=0){ //on reaching the last question disable the next button
				$('.prev').addClass('disabled');
			}
			else{
				$('.next').addClass('disabled'); //on reaching the first question disable the previous button
			}
		}
	});

	$('.container').on('click',' .panel-heading .panel-title a',function(){
		console.log('rotate now');
		$(this).find('img.arrow').toggleClass('rotate');
	});
});