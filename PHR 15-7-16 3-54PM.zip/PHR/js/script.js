"use strict";

// var carousel = document.getElementById('graph-carousel'),
//     firstPos, lastPos;

// carousel.addEventListener('touchstart', func1);
// carousel.addEventListener('touchmove', func2);

// function func1(e) {
//   firstPos = e.touches[0].pageX;
// }

// function func2(e) {
//   lastPos = e.touches[0].pageX;

//   if (lastPos > firstPos) {
//     swipe('right');
//   }
//   else if (firstPos > lastPos) {
//     swipe('left');
//   }
// }

// function swipe(direction) {
//   alert('swipe '+direction);
// }


var dots = $('#dots-wrap .dot'),
	dotList = [],
	radarRadius = $('.radar-circle.main').width() / 2,
	dotDiameter =$('#dots-wrap .dot:eq(0)').width(),
	effectiveDistance = radarRadius - dotDiameter - 5, // -5 is a cutoff
	animationDuration = 12,
	lengthList = [],
	degreeList = [],
	dObj = {
		'q1' : [],
		'q2' : [],
		'q3' : [],
		'q4' : []
	},
	qText = {
		'q1' : ['What', 'When', 'Where'],
		'q2' : ['Activity', 'Diet', 'Work'],
		'q3' : ['Genetic', 'Age'],
		'q4' : ['History', 'EHR']
	};

while (lengthList.length < 8) {
	var length = Math.floor((Math.random() * effectiveDistance) + 1);
	if (length > 10) { // 10 is offset
		lengthList.push(length);
	}	
}

while (dObj.q1.length + dObj.q2.length + dObj.q3.length + dObj.q4.length < 8) {
	var degree = Math.floor((Math.random() * 360) + 1);

	if (degree>=0 && degree<=90 && dObj.q1.length<2) {
		dObj.q1.push(degree);
		degreeList.push(degree);
	}
	else if (degree>=91 && degree<=180 && dObj.q2.length<2) {
		dObj.q2.push(degree);
		degreeList.push(degree);
	}
	else if (degree>=181 && degree<=270 && dObj.q3.length<2) {
		dObj.q3.push(degree);
		degreeList.push(degree);
	}
	else if (dObj.q4.length<2) {
		dObj.q4.push(degree);
		degreeList.push(degree);
	}
}

$('.radar-hand').css('animation-duration', animationDuration+'s');

var p = 0,
	q = 0,
	r = 0,
	s = 0;

for (var i=0; i<lengthList.length; i++) {
	var degree = degreeList[i],
		length = lengthList[i],
		radian = degree * Math.PI / 180,
		lenX = Math.abs(Math.floor(Math.cos(radian) * length)),
		lenY = Math.floor(Math.sqrt(Math.pow(length,2)-Math.pow(lenX,2)));
	
	// var string = '<p>Length: '+length+'<br>'+'Degree '+
	// 			  degree+'<br>'+'Radian '+radian+'<br>'+
	// 			  'X-axis '+lenX+'<br>'+'Y-axis '+lenY+'</p>';
	// $('body').append(string);

	if (degree>=0 && degree<=90) {
		$(dots[i]).css({
			'left' : lenX+'px',
			'top' : -lenY+'px'
		}).html('<span>'+qText.q1[p]+'</span>');
		p = p + 1;
	}
	else if (degree>=91 && degree<=180) {
		$(dots[i]).css({
			'left' : -lenX+'px',
			'top' : -lenY+'px'
		}).html('<span>'+qText.q2[q]+'</span>');
		q = q + 1;
	}
	else if (degree>=181 && degree<=270) {
		$(dots[i]).css({
			'left' : -lenX+'px',
			'top' : lenY+'px'
		}).html('<span>'+qText.q3[r]+'</span>');
		r = r + 1;
	}
	else {
		$(dots[i]).css({
			'left' : lenX+'px',
			'top' : lenY+'px'
		}).html('<span>'+qText.q4[s]+'</span>');
		s = s + 1;
	}

	$(dots[i]).css({
		'animation-delay' : ((animationDuration/360)*(90-degree))+'s',
		'animation-duration' : animationDuration+'s'
	});
}

// Make the rader center aligned(full page view)
// BAD

(function adjustElementHeights() {
	var x = 0;

	$('#title-bar, #message-box, #navigation-bar').each(function() {
		x += $(this).outerHeight();
	});

	var mainContent = $('#main-content'),
		iniHeight = mainContent.outerHeight(),
		windowHeight = $(window).outerHeight(),
		extendedHeight = windowHeight - x;

	if (x + iniHeight <= windowHeight) {
		mainContent.css({
			'height' : extendedHeight+'px',
			'padding' : (extendedHeight - iniHeight)/2+'px 0'
		});
	};
})();