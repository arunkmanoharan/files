<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-plugin/tag-cloud-widget/qa-tag-cloud.php
	Description: Widget module class for tag cloud plugin


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
*/
	function qa_page_routing()
	{
		$pages = qa_page_routing_base();
		
		
		//if (qa_opt('tos_serverside'))
		$pages['tags'] = '../qa-plugin/nimeyo-custom/qa-page-tags.php';
		$pages['tags/recent'] = '../qa-plugin/nimeyo-custom/qa-page-tags-recent.php';
		$pages['tags/hot'] = '../qa-plugin/nimeyo-custom/qa-page-tags-hot.php';
		$pages['tags/name'] = '../qa-plugin/nimeyo-custom/qa-page-tags-name.php';
		$pages['users'] = '../qa-plugin/nimeyo-custom/qa-page-users.php';
		$pages['userdetail/'] = '../qa-plugin/nimeyo-custom/qa-page-user.php';
		$pages['user/'] = '../qa-plugin/nimeyo-custom/qa-page-user.php';
		$pages['users/blocked'] = '../qa-plugin/nimeyo-custom/qa-page-users-inactive.php';
		$pages['users/active'] = '../qa-plugin/nimeyo-custom/qa-page-users.php';
		$pages['dashboard'] = '../qa-plugin/nimeyo-custom/qa-page-dashboard.php';
		$pages['admin/layoutwidgets'] = '../qa-plugin/nimeyo-custom/qa-page-admin-widgets.php';
	
		// changed to include a new file instead of default page
		return $pages;
	}

