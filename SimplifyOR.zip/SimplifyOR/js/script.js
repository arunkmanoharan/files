$(document).ready(function(){

	$('a[href^="#"]').on('click', function(event) {
		var target = $(this.getAttribute('href'));
		if( target.length ) {
			event.preventDefault();
			$('html, body').stop().animate({
				scrollTop: target.offset().top
			}, 1000);
		}
		$(this).parent('li').siblings('li').removeClass('active');
		$(this).parent('li').addClass('active');
	});

	$('.box').hover(function(){
		$(this).siblings('.text').fadeToggle(100);
	});

	function isElementInViewport (el) {

		if (typeof jQuery === "function" && el instanceof jQuery) {
			el = el[0];
		}

		var rect = el.getBoundingClientRect();

		return (
			rect.top >= 0 &&
			rect.left >= 0 &&
			rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && /*or $(window).height() */
			rect.right <= (window.innerWidth || document.documentElement.clientWidth) /*or $(window).width() */
			);
	}

	$(window).scroll(function(){
		var nav = $('#header');
		if(isElementInViewport(nav) == false && $('.side-links').is(':hidden')){
			$('.side-links').fadeIn(1000);
		}
		else if(isElementInViewport(nav) == true){
			$('.side-links').fadeOut(100);
		}
	});
});
