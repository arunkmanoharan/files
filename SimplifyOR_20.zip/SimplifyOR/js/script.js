$(document).ready(function(){

// 	$('#carousel-example').carousel({
//     pause: true,
//     interval: false
// });

	$('a[href^="#"]').on('click', function(event) {
		var target = $(this.getAttribute('href'));
		if( target.length ) {
			event.preventDefault();
			$('html, body').stop().animate({
				scrollTop: target.offset().top - 80
			}, 1000);
		}
		$(this).parent('li').siblings('li').removeClass('active');
		$(this).parent('li').addClass('active');

		var clickedLink = $(this);
		
		var selectedLink = $('a').filter(function(index) {
			return $(this).text().toUpperCase() === $(clickedLink).siblings().text().toUpperCase() ; 
		});

		console.log();

		$(selectedLink).parent('li').siblings('li').removeClass('active');
		$(selectedLink).parent('li').addClass('active');


	});

	$('div[id]').on('mouseenter touchenter mouseleave touchleave touchmove',function(){

		var id = $(this).attr('id');

		$('a[href="#' + id + '"]').parent().siblings('li').removeClass('active');
		$('a[href="#' + id + '"]').parent().addClass('active');
		$('.side-links ul li a').removeClass('hover');
		$('a[href="#' + id + '"]').addClass('hover');

		
	});

	$('.box').hover(function(){
		$(this).siblings('.text').fadeToggle(100);
	});

	$(window).scroll(function(){

		$('.navbar').toggleClass('shrink', $(document).scrollTop() > 50);
		$('.navbar .nav li').toggleClass('shrink', $(document).scrollTop() > 50);
		$('.navbar-brand img').toggleClass('shrink', $(document).scrollTop() > 50);

		var showNow = $('#intended-audience').offset().top / 1.5;

		if($(document).scrollTop() > showNow){
			$('.side-links').fadeIn(300);
		}
		else{
			$('.side-links').fadeOut(300);
		}
		
	});

	
	$('.nav a').on('click', function(){
		if ($(window).width() < 768) {
		    $('.btn-navbar').click(); //bootstrap 2.x
		    $('.navbar-toggle').click() //bootstrap 3.x 
		}
	});
	
	

});
