'use strict';


/*--------------------------------------------------------------------------
                                  Carousel
--------------------------------------------------------------------------*/
// Initialize Carousel
var carouselList = $('.carousel'),
	slideDuration = 600, // Same as transition duration
	lastIndicatorClick;

carouselList.each(function() {

	// Adding handlers to carousel indicators
	if ($(this).children('.carousel-indicator-wrap').length > 0) {
		var activeItemIndex = $(this).children('.carousel-item.active').index();

		// Add 'active' class to indicator
		$(this).find('.carousel-indicator').eq(activeItemIndex).addClass('active');
		$(this).find('.carousel-indicator').click(function() {
			if (processCarouselClick()) {
				slideToItem($(this).closest('.carousel').children('.carousel-item').eq($(this).index()));
			}
		});
	}

	// Adding handlers to carousel controls
	if ($(this).children('.carousel-control-wrap').length > 0) {
		$(this).find('.carousel-control').click(function() {
			if (processCarouselClick()) {
				var activeItem = $(this).closest('.carousel').children('.carousel-item.active'),
					nextItem = activeItem.next(),
					prevItem = activeItem.prev(),
					goToItem;

				if ($(this).hasClass('next')) {
					goToItem = nextItem.hasClass('carousel-item') ? nextItem : activeItem.siblings().eq(0);
				}
				else {
					goToItem = prevItem.hasClass('carousel-item') ? prevItem : activeItem.siblings('.carousel-item').last();
				}

				slideToItem(goToItem);
			}
		});
	}
});

// Validates the click event
function processCarouselClick() {
	var currentIndicatorClick = new Date().getTime(),
		clickStatus = false;

	if (lastIndicatorClick == null || currentIndicatorClick-lastIndicatorClick > slideDuration) {
		clickStatus = true;
		lastIndicatorClick = currentIndicatorClick;
	}

	return clickStatus;
}

// Slides to the successive item
function slideToItem(successiveItem) {
	var carousel = successiveItem.closest('.carousel'),
		activeItem = carousel.find('.carousel-item.active'),
		activeItemIndex = activeItem.index(),
		successiveItemIndex = successiveItem.index();

	// Slide left
	if (activeItemIndex < successiveItemIndex) {
		successiveItem.addClass('next');
		// Delay between class changes
		setTimeout(function() {
			activeItem.add(successiveItem).addClass('left');
		}, 30);

		setTimeout(function() {
			activeItem.removeClass('active left');
			successiveItem.removeClass('next left').addClass('active');
		}, slideDuration);
	}
	// Slide right
	else if ( activeItemIndex > successiveItemIndex) {
		successiveItem.addClass('prev');
		// Delay between class changes
		setTimeout(function() {
			activeItem.add(successiveItem).addClass('right');
		}, 30);

		setTimeout(function() {
			activeItem.removeClass('active right');
			successiveItem.removeClass('prev right').addClass('active');
		}, slideDuration);
	}

	// Update carousel indicator
	carousel.find('.carousel-indicator').eq(successiveItemIndex).addClass('active').siblings().removeClass('active');
}


/*--------------------------------------------------------------------------
                               Block Highlight
--------------------------------------------------------------------------*/
$('#enterprise-info, #enterprise-benefits').find('.block-content').on( 'mouseenter', function() {
	$(this).addClass('highlight-content').siblings().removeClass('highlight-content');
});

/*--------------------------------------------------------------------------
                               Overlay Menu
--------------------------------------------------------------------------*/
var overlayMenu = $('.overlay-menu');

overlayMenu.children('.menu-close').add('#header .ham-logo').click(function() {
	overlayMenu.toggleClass('hide');
});
