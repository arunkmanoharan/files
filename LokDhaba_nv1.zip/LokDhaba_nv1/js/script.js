$(document).ready(function(){ // when the document is loaded completely
	
	$('.autocomplete input.autocomplete-input').on('keyup',function(){
		var filterText = $(this).val();
		$(this).parent().siblings('ul.autocomplete-list').find('li').each(function(){
			var item = $(this).text();
			if(!(item.toUpperCase()).includes(filterText.toUpperCase())){
				$(this).hide();
			}else{
				$(this).show();
			}
		});
	});
	
	$('.autocomplete-dropdown').on('click',function(e){
		e.preventDefault();
		
		$(this).find('ul.autocomplete-list li').each(function(){
			$(this).show();
		});
		
	}).find('input, ul.autocomplete-list').on('click',function() {
	  return false;
	});
	
	
	$('.autocomplete-dropdown ul.autocomplete-list li').on('click',function(){
		$(this).parents('.autocomplete-dropdown').find('input.autocomplete-input').val($(this).text());
	});

});