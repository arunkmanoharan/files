var app = angular.module('Application',[]);

app.controller('questionCtrl', function($scope) {

   //data from server, JSON array containing all the questions
   
   $scope.question = [{"no":"1",
   					   "img":"img/lion.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"2",
   					   "img":"img/giraffe.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"2",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"3",
   					   "img":"img/rabbit.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"4",
   					   "img":"img/butterfly.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"3",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"5",
   					   "img":"img/lion.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"6",
   					   "img":"img/giraffe.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"2",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"7",
   					   "img":"img/rabbit.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"8",
   					   "img":"img/butterfly.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"3",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"9",
   					   "img":"img/lion.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"10",
   					   "img":"img/giraffe.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"11",
   					   "img":"img/rabbit.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"12",
   					   "img":"img/butterfly.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"13",
   					   "img":"img/lion.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"14",
   					   "img":"img/giraffe.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  },
   					  {"no":"15",
   					   "img":"img/rabbit.jpg",
   					   "ques":"Why did Cecil the lion became known around the world?",
   					   "options":[{"id":"op1","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op2","class":"","text":"He was the inspiration for Lion king"},
   					   			  {"id":"op3","class":"","text":"He was killed by Minnesota dentist"},
   					   			  {"id":"op4","class":"","text":"He was killed by Minnesota dentist"},	
   					   			 ],
   					   "correct":"1",
   					   "relatedLink":"Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum "
   					  }
   					  ];

      //currently displayed question
      $scope.current = 0 
      
      // default classes for the ques no., if user hasn't marked the answer or none of them are selected
      $scope.classArray = ["","","","","","","","","","","","","","",""]; 
      
      //set class to active for the current question displayed
      $scope.classArray[$scope.current] += " active";

      $scope.correct = 0; //no. of correct questions
      $scope.incorrect = 0; //no. of incorrect questions
      $scope.totalQues = $scope.question.length; //total no. of questions

      $scope.showResult = false; // variable display result after submit button is clicked, initially false

      $scope.answers = {}; //Object which stores questions and answers ans key value pairs
      $scope.score = 0;

      $scope.highScore = 130; //highest score, from database
      $scope.avgScore = 70; // average score, also from database
      $scope.maxMarks = $scope.totalQues * 10; // max. marks,

      //function to add a class (active, correct, incorrect) to a question
      $scope.addClassToQuesNo = function(className, qno){
         $scope.classArray[qno] = $scope.classArray[qno] + " "+className;
      }

      //function to remove active class from all the questions
      $scope.removeActiveClassFromQuesNo = function() {
         for (i in $scope.classArray){
            var val = $scope.classArray[i];
            $scope.classArray[i] = val.replace("active","");
         }
      }

      //function to deselect all the options
      $scope.removeActiveClassFromAllOptions = function(qno) {
         for (i in $scope.question[qno].options){
            $scope.question[qno].options[i].class = $scope.question[qno].options[i].class.replace("active","");
         }
      }

      //function to move to next question when user clicks on next
      $scope.gotoNext = function(){
         if($scope.current<$scope.question.length-1){
            $scope.nextDisabled = false;
            $scope.current++;
            $scope.removeActiveClassFromQuesNo();
            $scope.addClassToQuesNo("active",$scope.current);
         }
      }

      //function to move to previous question when user clicks on previous
      $scope.gotoPrev = function(){
         if($scope.current>0){
            $scope.prevDisabled = false;
            $scope.current--;
            $scope.removeActiveClassFromQuesNo();
            $scope.addClassToQuesNo("active",$scope.current);
         }
      }

      //function to perform calculations and display required data when user clicks on submit button
   	$scope.submitAnswers = function() { 
   		var yORn = confirm("Do want to submit your answers?"); 
   		if(yORn){
   			$scope.calculateScore();
            $scope.current = 0;
            $scope.removeActiveClassFromQuesNo();
            $scope.classArray[$scope.current] += " active";
   		}
   	}

      //function called when user clicks on an option, it captures the selected option
      $scope.addToAnswer = function(qno,op) { 
         var ques = qno; //getting question no.
         var option = op.replace("op",""); //getting the option chosen by user (converting 'op1' -> '1')
         $scope.answers[ques] = option; //adding them to the object
         $scope.removeActiveClassFromAllOptions(qno-1);
         $scope.question[qno-1].options[option-1].class = "active";
      }

      // returns the correct answer of the question passed as parameter
      $scope.answerFor = function(ques){
                           for (i in $scope.question){
                              if($scope.question[i].no == ques){
                                 return $scope.question[i].correct;
                              }
                           }
                        }

      // function to set class of the options green if user's answer is correct, else red.
      $scope.setClass = function(ques,option,className){
                           for (k in $scope.question){
                              if($scope.question[k].no == ques){
                                 for(l in $scope.question[k].options){
                                    if($scope.question[k].options[l].id == option){
                                       $scope.question[k].options[l].class = className;
                                       break;
                                    }
                                 }
                              }
                           }
                        }
      
      $scope.calculateScore = function() { //function to calculate score
         $scope.showResult = true; //display the resuult
         
         for(j in $scope.answers){ //code for calculating score
            
            if($scope.answerFor(j) == $scope.answers[j]){ //if the answer is correct
               $scope.classArray[j-1] = "correct";
               $scope.score += 10;
               $scope.correct ++;
               $scope.setClass(j,"op"+$scope.answers[j],"correct");
            }
            else{                                        // if the answer is incorrect
               $scope.classArray[j-1] = "incorrect";
               $scope.incorrect++;
               $scope.setClass(j,"op"+$scope.answerFor(j),"correct");
               $scope.setClass(j,"op"+$scope.answers[j],"incorrect");
            }  
         }
      }

      // set the color of the ques no. red/green if the anser is incorrect/correct
      $scope.setBulletClass =function(item){ 
         console.log($scope.answerFor(item.no)+' : '+$scope.answers[item.no]);
         return "correct";
      }

      //for rating the quiz
      $scope.starIndex = [1,2,3,4,5]; 
      $scope.starClass = { 0 : "glyphicon glyphicon-star",
                           1 : "glyphicon glyphicon-star",
                           2 : "glyphicon glyphicon-star",
                           3 : "glyphicon glyphicon-star",
                           4 : "glyphicon glyphicon-star"
                         };
      
      $scope.rate = function(rating) {
         $scope.starClass = { 0 : "glyphicon glyphicon-star",
                              1 : "glyphicon glyphicon-star",
                              2 : "glyphicon glyphicon-star",
                              3 : "glyphicon glyphicon-star",
                              4 : "glyphicon glyphicon-star"
                            };
         for(i=0;i<rating+1;i++){
            $scope.starClass[i] = "glyphicon glyphicon-star selected";
         }
      };  
});