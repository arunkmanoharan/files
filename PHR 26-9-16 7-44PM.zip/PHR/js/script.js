/*--------------------------------------------------------------------
							SCOREBOARD
--------------------------------------------------------------------*/

/*----------------------- Daily Score Circle -----------------------*/
if ($('#progress-circle').length > 0) {
	drawProgressCircle($('#progress-circle'), 86);
}

function drawProgressCircle(canvas, percentage) {
	var canvasWrap = canvas.parent('.canvas-wrap'),
		width = canvasWrap.width(),
		height = canvasWrap.height(),
		center = width / 2,
		radius = center - 5, // 5px padding
		ctx = canvas[0].getContext('2d');

	// Set Canvas Size
	canvas.attr({
		width: width,
		height: height
	});

	// Gray Circle
	ctx.strokeStyle = '#EAE9E9';
	ctx.lineWidth = 2.5;
	ctx.beginPath();
	ctx.arc(center, center, radius, 0, 2*Math.PI);
	ctx.stroke();

	// Progress Circle
	var startAngle = 1.5*Math.PI,
		endAngle = (percentage == 100) ? 3.5*Math.PI : (((percentage/100)*2)-0.5)*Math.PI;

	ctx.strokeStyle = '#00AEF1';
	ctx.lineWidth = 2.5;
	ctx.beginPath();
	ctx.arc(center, center, radius, startAngle, endAngle);
	ctx.stroke();

	// Progress Text
	$(canvas).next().text(percentage+'%');
}

/*------------------------ Dashboard Carousel ----------------------*/
$('.carousel-indicator').click(slideCarouseWithIndicator);

var carTouchStartPoint, carTouchCurrentPoint,
	swipeGap = $(window).width() / $('.carousel-img').length;

$('.di-carousel-inner').on({
	touchstart : function(event) {
		touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
		carTouchStartPoint = touch.pageX;
		// console.log('Start Point: ' + carTouchStartPoint);
	},
	touchmove : function(event) {
		touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
		carTouchCurrentPoint = touch.pageX;
		// console.log('Current Point: ' + carTouchCurrentPoint);

		if (Math.abs(carTouchCurrentPoint-carTouchStartPoint) > swipeGap) {
			if (carTouchCurrentPoint-carTouchStartPoint > 0) {
				// console.log('Swipe backward');
				slideCarouseWithTouch('backward');
			}
			else {
				// console.log('Swipe forward');
				slideCarouseWithTouch('forward');
			}
			carTouchStartPoint = carTouchCurrentPoint;
		}
	}
});

function slideCarouseWithIndicator() {
	var goToSlide = $(this).index();


	$('.di-carousel-inner').css({
		'margin-left' : -goToSlide*100+'%'
	}).attr('data-current-slide', goToSlide);

	$('.carousel-indicator.active').removeClass('active');
	$(this).addClass('active');
}

function slideCarouseWithTouch(direction) {
	var carouselInner = $('.di-carousel-inner'),
		currentSlide = parseInt(carouselInner.attr('data-current-slide'));

	if (direction == 'forward' && currentSlide+1<carouselInner.children().length) {
		carouselInner.attr('data-current-slide', currentSlide+1).css('margin-left', -(currentSlide+1)*100+'%');
		$('.carousel-indicator.active').removeClass('active').next().addClass('active');
	}
	else if (direction == 'backward' && currentSlide>0) {
		carouselInner.attr('data-current-slide', currentSlide-1).css('margin-left', -(currentSlide-1)*100+'%');
		$('.carousel-indicator.active').removeClass('active').prev().addClass('active');
	}
}

/*------------------------------ Modal -----------------------------*/
var modal = $('#modal-glass'),
	modalHeading = modal.find('.modal-heading'),
	modalBody = modal.find('.modal-body'),
	modalControl = modal.find('.modal-control');

// Close modal on click over controls
$('.modal-control-wrap').on('click', '.modal-control', hideResetModal);

// Elements with attribute 'data-modal' triggers modal
$('[data-modal]').click(showPopulatedModal);

// Empty heading & body, reset footer
function hideResetModal() {
	// Empty modal
	modalHeading.empty();
	modalBody.empty();

	// Reset modal control
	modal.find('.modal-control-wrap').html(modalControl);

	// Hide modal
	modal.addClass('hide');
}

// Populates modal based on corresponding'data-modal-content'
function showPopulatedModal() {
	var modalData = $('.modal-content-wrap [data-modal-content="'+$(this).attr('data-modal')+'"]');

	if (modalData.length > 0) {
		// Populate modal heading & body
		modalHeading.text(modalData.children('[data-modal-heading]').text());
		modalBody.html(modalData.children('[data-modal-body]').html());

		// Replace default control with DEEP-copied custom control
		var modalControl = modalData.find('.modal-control').clone(true);
		if (modalControl.length > 0) {
			modal.find('.modal-control').replaceWith(modalControl);
		}

		// Show modal
		modal.removeClass('hide');
	}	
}

// NOTE :: In order to assign custom modal event handlers to custom controls,
// simply add those to the controls of the element with 'data-modal' attribute

/*-------------------------- Factor Content ------------------------*/
$('.quadrant-factors .factor').click(showSelectedFactor);

function showSelectedFactor() {
	var quadDesc = $('.quadrant-description'),
		factorContentWrap = $('.factor-contents-wrap'),
		factorContent = $('.factor-content[data-factor-content="' + $(this).attr('data-factor') + '"]');

	// showing selected tile 
	$(this).toggleClass('active').siblings().removeClass('active');
	// showing the content of the selected tile
	$('.factor-content').not(factorContent).addClass('hide');
	factorContent.toggleClass('hide');

	if ($(this).siblings().addBack().hasClass('active')) {
		quadDesc.addClass('hide');
		factorContentWrap.removeClass('hide');
	}
	else {
		quadDesc.removeClass('hide');
		factorContentWrap.addClass('hide');
	}
}

/*--------------------- Number Input Control -----------------------*/
$('.number-input-wrap .control-icon').click(tuneInputControl);

function tuneInputControl() {
	var inputControl = $(this).parent().find('input[type="text"]'),
		currentVal = parseInt(inputControl.val());

	if (isNaN(currentVal)) {
		inputControl.val(0); // Reset value to zero
	}
	else {
		if ($(this).hasClass('decrease') && currentVal>0) {
			inputControl.val(currentVal-1);
		}
		else if ($(this).hasClass('increase')) {
			inputControl.val(currentVal+1);
		}
	}	
}

/*--------------------- Slider Input Control -----------------------*/
// Set initial slider percentage
$('.slider-input-wrap').each(setInitialSlider);

// Adjust slider on click and drag
var sliderWidth, offsetLeft, ass;

$('.slider-input-wrap').on({
	'touchstart mousedown': function() {
		// Common stuff that doesn't need execution multiple times
		sliderWidth = $(this).width(),
		offsetLeft = this.offsetLeft;

		// Single click adjust
		adjustSliderDrag(this);

		// Drag adjust
		$(this).on({
			'touchmove mousemove': function() {
				adjustSliderDrag(this);
			}
		});
	},
	'touchend touchleave mouseup mouseleave': function() {
		$(this).unbind('touchmove mousemove');
		// console.log('Handler unbound');
	},
	'touchend mouseup': function() {
		// Shift to steps only when slider is clicked/dragged
		moveSliderToStep(this);
	}
});

function adjustSliderDrag(element) {
	var posX, percentage,
		eventType = event.type,
		elem = $(element);

	if (eventType=='touchstart' || eventType=='touchmove') { // for touch events
		posX = event.touches[0].pageX - offsetLeft;
	}
	else { //for mouse events
		posX = event.pageX - offsetLeft
	}
	
	// Fixing the offset of the slider handle
	posX = (posX < 0) ? 0 : posX;
	posX = (posX > sliderWidth) ? sliderWidth : posX;
	percentage = posX/sliderWidth*100;

	positionSlider(element, percentage);
}

function setInitialSlider() {
	var totalSteps = $(this).find('.slider-step').length || 2,
		stepAttr = $(this).children('.slider').attr('data-current-step'),
		currentStep = (stepAttr && parseInt(stepAttr)>0) ? parseInt(stepAttr) : 1,
		divisionWidth = 100 / (totalSteps-1);
		percentage = divisionWidth*(currentStep-1);

	if (currentStep <= totalSteps) {
		positionSlider(this, percentage);
	}
}

function moveSliderToStep(element) {
	var elem = $(element),
		totalSteps = elem.find('.slider-step').length,
		divisionWidth = 100 / (totalSteps-1),
		percentage = elem.find('input').val(),
		stepArray = [0, 100],
		betweenArray = [],
		nearestStep;

	for(var i=0; i<totalSteps-2; i++) {
		stepArray.splice((i+1), 0, (i+1)*divisionWidth);
	}
	// console.log(stepArray);

	for (var j=0; j<totalSteps; j++) {
		if (Math.abs(percentage-stepArray[j])<=divisionWidth) {
			// console.log('Step: '+stepArray[j]);
			betweenArray.push(stepArray[j]);
		}
	}

	if (Math.abs(percentage-betweenArray[0])<Math.abs(percentage-betweenArray[1])) {
		nearestStep = betweenArray[0];
	}
	else {
		nearestStep = betweenArray[1];
	}
	// console.log('Nearest Step: '+nearestStep);
	positionSlider(element, nearestStep);
}

function positionSlider(element, percentage) {
	var elem = $(element),
		perc = Math.round(percentage*100) / 100;

	elem.find('input').val(perc);

	elem.find('.slider-handle').css({
		left: perc + '%'
	});
	elem.find('.slider-fill').css({
		width: perc + '%'
	});

	// console.log('Slider handle positioned.');
}

/*--------------------- Toggle Input Control -----------------------*/
$('.toggle-button').on({
	click: toggleOption
});

function toggleOption() {
	$(this).toggleClass('active');
}

/*----------------------- Dropdown Control -------------------------*/
$('.dropdown').click(function() {
	$(this).find('.dropdown-options').toggleClass('hide').parent('.dropdown').toggleClass('dropdown-open');
});

$('.dropdown-options li').click(function() {
	$(this).parent().siblings('.selected-option').text($(this).text());
});

/*------------------------ Hamburger Menu --------------------------*/
$('.ham-menu').click(function() {
	$(this).children('.header-menu-wrap').fadeIn().children('.header-menu').slideDown();
});

$('.header-menu-wrap').click(function(event) {
	$(this).fadeOut().children('.header-menu').slideUp();
	event.stopPropagation();
}).children('.header-menu').click(function(event) {
	event.stopPropagation();
});


/*------------------------- Log Calendar ---------------------------*/
// data-viewing-month
// data-adjacent-month

var today = new Date(),
	monthArray = ['January','February','March','April','May','June','July','August','September','October','November','December'];

$('.calendar').each(generateCalendar);

function generateCalendar() {
	// Initially current date
	var dateObj = new Date(),
		date = dateObj.getDate(),
		month = dateObj.getMonth(),
		refDate = new Date();

	$(this).find('.month-name').text(monthArray[month]+' '+dateObj.getFullYear());
	refDate.setDate(date-dateObj.getDay());

	// Set date to 1st of month
	dateObj.setDate(1);

	// Set date back to nearest(last) Sunday
	dateObj.setDate(dateObj.getDate()-dateObj.getDay());

	$(this).find('.calendar-column').each(function(i) {
		// Initially same as 'dateObj'
		var tempDate = new Date(dateObj);

		for (var j=0; j<5; j++) {
			var	calDateElem = $('<div class="calendar-date">'+tempDate.getDate()+'</div>');

			// Check month
			if (tempDate.getMonth() == month) {
				calDateElem.addClass('view-month');
			}
			else if (tempDate.getMonth() < month) {
				calDateElem.addClass('prev-month');
			}
			else {
				calDateElem.addClass('next-month');
			}

			// Check week
			if (tempDate.getDate()-refDate.getDate()==i) {
				calDateElem.addClass('view-week');
			}

			// Check date
			if (tempDate.getMonth()==month && tempDate.getDate()==date) {
				calDateElem.addClass('selected-date');
			}

			$(this).append(calDateElem);

			tempDate.setDate(tempDate.getDate()+7);
		}

		// Increase day by one
		dateObj.setDate(dateObj.getDate()+1);
	});
}

$('.calendar .calendar-expand').click(function() {
	$(this).closest('.calendar').find('.calendar-box').toggleClass('calendar-expanded');
});



































/*--------------------------------------------------------------------
						  TEMPORARY GARBAGE
--------------------------------------------------------------------*/
$('.header-nav-option.back-button').click(function() {
	window.history.back();
});

if ($('.dark-btn, .green-btn').length==2) {
	var currentQuadrant = $('.header-title').text().split(' ')[0].toLowerCase(),
		footerNavigation = $('#footer'),
		prevBtn = footerNavigation.children().eq(0),
		nextBtn = footerNavigation.children().eq(1);

	// console.log(currentQuadrant);

	if (currentQuadrant == 'existential') {
		nextBtn.click(function(){openPage('lifestyle.html')});
	}
	else if (currentQuadrant == 'lifestyle') {
		prevBtn.click(function(){openPage('existential.html')});
		nextBtn.click(function(){openPage('symptoms.html')});
	}
	else if (currentQuadrant == 'symptoms') {
		prevBtn.click(function(){openPage('lifestyle.html')});
		nextBtn.click(function(){openPage('clinical.html')});
	}
	else if (currentQuadrant == 'clinical') {
		prevBtn.click(function(){openPage('symptoms.html')});
		// nextBtn.click(function(){openPage('radar.html')});
	}
}

function openPage(url) {
	window.open(url, '_self');
}

$('.factor[data-factor="diet"]').click(function() {openPage('diet-input.html')});
$('.factor[data-factor="symptoms"]').click(function() {openPage('symptoms-input.html')});
$('.warning-message-box').click(function() {openPage('warning.html')});
$('.mini-desc.recommendation-block').unbind('click').click(function(){
	if ($(this).attr('data-recommendation')=='exercise') {openPage('exercise-guidance.html')}
	else if ($(this).attr('data-recommendation')=='diet') {openPage('diet-guidance.html')}
});

// radar quadrant redirection
$('.radar-quadrant.quadrant-first').click(function(){openPage('symptoms.html')});
$('.radar-quadrant.quadrant-second').click(function(){openPage('lifestyle.html')});
$('.radar-quadrant.quadrant-third').click(function(){openPage('existential.html')});
$('.radar-quadrant.quadrant-fourth').click(function(){openPage('clinical.html')});


var animDur = 3000;
if ($('.entry-radar .initiate-radar').length > 0) {
	$('[data-modal-content="disclaimer"] .control-accept').on('click', function(event) {
		$('.entry-radar .initiate-radar').fadeOut('400', function() {
			$('.entry-radar .radar-hand').css({
				'animation-name': 'rotate',
				'animation-iteration-count': 1,
				'animation-duration': (animDur/1000)+'s'
			});

			setTimeout(function() {
				$('.radar-quadrants-wrap .quadrant-third').removeClass('hide').css({				
					'padding-bottom': '50%',
					'cursor': 'pointer',
					'background': 'rgba(234, 233, 233, 0.8)',
					'opacity': 0,
					'animation': 'quadrant-pulsate 1.5s linear '+ 1/4*animDur/1000 +'s infinite'
				}).animate({
					'opacity': 1
				}, 1/8*animDur);

				$('.radar-quadrants-wrap .quadrant-third').on({
					'mouseover': function() {
						$(this).addClass('quadrant-arc');
					},
					'mouseleave': function() {
						$(this).removeClass('quadrant-arc');
					}
				});

			}, 3/4*animDur);

			setTimeout(function() {
				$('.radar-hand').animate({
					'opacity': 0
				}, 2000);
			}, 7/8*animDur);
		});
	});
}

$('.radio-input-wrap input[name="gender"]').change(function() {
	if ($(this).val()=='woman') {
		$(this).closest('.box').next('.toggle-control-block').removeClass('hide');
	}
	else {
		$(this).closest('.box').next('.toggle-control-block').addClass('hide');
	}
});

$('.footer-nav-item.nav-radar').click(function() {openPage('radar.html')});
$('.footer-nav-item.nav-scorecard').click(function() {openPage('scorecard.html')});
$('.footer-nav-item.nav-diet-activity').click(function() {openPage('log-diet-activity.html')});

$('.factors-data-import[data-quadrant-import="clinical"]').click(function(){openPage('login-charm.html')});

$('.dashboard-item.symptoms').click(function() {openPage('log-symptoms.html')});
$('.dashboard-item.clinical').click(function() {openPage('log-clinical.html')});
$('.dashboard-item.diet, .dashboard-item.activity').click(function() {openPage('log-diet-activity.html')});
$('.phr-login-form input[name="login"][type="button"]').click(function(){openPage('recommendation.html')});
$('.footer-button[data-control-function="save"]').click(function(){openPage('scorecard.html')});

$('[data-modal-content="clinical-confirm"] .control-accept').click(function(){openPage('radar.html')});
