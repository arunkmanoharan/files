/*--------------------------------------------------------------------
							SCOREBOARD
--------------------------------------------------------------------*/

/*----------------------- Daily Score Circle -----------------------*/
if ($('#progress-circle').length > 0) {
	drawProgressCircle($('#progress-circle'), 86);
}

function drawProgressCircle(canvas, percentage) {
	var canvasWrap = canvas.parent('.canvas-wrap'),
		width = canvasWrap.width(),
		height = canvasWrap.height(),
		center = width / 2,
		radius = center - 5, // 5px padding
		ctx = canvas[0].getContext('2d');

	// Set Canvas Size
	canvas.attr({
		width: width,
		height: height
	});

	// Gray Circle
	ctx.strokeStyle = '#EAE9E9';
	ctx.lineWidth = 2.5;
	ctx.beginPath();
	ctx.arc(center, center, radius, 0, 2*Math.PI);
	ctx.stroke();

	// Progress Circle
	var startAngle = 1.5*Math.PI,
		endAngle = (percentage == 100) ? 3.5*Math.PI : (((percentage/100)*2)-0.5)*Math.PI;

	ctx.strokeStyle = '#00AEF1';
	ctx.lineWidth = 2.5;
	ctx.beginPath();
	ctx.arc(center, center, radius, startAngle, endAngle);
	ctx.stroke();

	// Progress Text
	$(canvas).next().text(percentage+'%');
}

/*------------------------ Dashboard Carousel ----------------------*/
$('.carousel-indicator').click(slideCarouseWithIndicator);

var carTouchStartPoint, carTouchCurrentPoint,
	swipeGap = $(window).width() / $('.carousel-img').length;

$('.di-carousel-inner').on({
	touchstart : function(event) {
		touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
		carTouchStartPoint = touch.pageX;
		// console.log('Start Point: ' + carTouchStartPoint);
	},
	touchmove : function(event) {
		touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
		carTouchCurrentPoint = touch.pageX;
		// console.log('Current Point: ' + carTouchCurrentPoint);

		if (Math.abs(carTouchCurrentPoint-carTouchStartPoint) > swipeGap) {
			if (carTouchCurrentPoint-carTouchStartPoint > 0) {
				// console.log('Swipe backward');
				slideCarouseWithTouch('backward');
			}
			else {
				// console.log('Swipe forward');
				slideCarouseWithTouch('forward');
			}
			carTouchStartPoint = carTouchCurrentPoint;
		}
	}
});

function slideCarouseWithIndicator() {
	var goToSlide = $(this).index();


	$('.di-carousel-inner').css({
		'margin-left' : -goToSlide*100+'%'
	}).attr('data-current-slide', goToSlide);

	$('.carousel-indicator.active').removeClass('active');
	$(this).addClass('active');
}

function slideCarouseWithTouch(direction) {
	var carouselInner = $('.di-carousel-inner'),
		currentSlide = parseInt(carouselInner.attr('data-current-slide'));

	if (direction == 'forward' && currentSlide+1<carouselInner.children().length) {
		carouselInner.attr('data-current-slide', currentSlide+1).css('margin-left', -(currentSlide+1)*100+'%');
		$('.carousel-indicator.active').removeClass('active').next().addClass('active');
	}
	else if (direction == 'backward' && currentSlide>0) {
		carouselInner.attr('data-current-slide', currentSlide-1).css('margin-left', -(currentSlide-1)*100+'%');
		$('.carousel-indicator.active').removeClass('active').prev().addClass('active');
	}
}

/*------------------------------ Modal -----------------------------*/
var modal = $('#modal-glass'),
	modalHead = modal.find('.modal-heading'),
	modalBody = modal.find('.modal-body');

$('.control-close, .control-decline').click(hideStrippedTextModal);
$('.box.mini-desc').click(showDetailedDesc);
$('.factor-dot').click(showFactorDotDesc);
$('.tile-extra-block .info-icon').click(showInfoIconDesc);
$('.entry-radar .initiate-radar').click(showDisclaimer);
$('.box.tile-box[data-tile-info]').click(showTileDetails);

if ($('[data-quadrant-name="clinical"]').length > 0) {
	$('.footer-button.green-btn').click(showClinicalConfirmModal);

	$('.modal-control-wrap').on('click', '.control-accept', function() {
		modalBody.next().html($('<div class="modal-control control-close">Close</div>'));
		hideStrippedTextModal();
		openPage('radar.html');
	}).on('click', '.control-decline', function() {
		modalBody.next().html($('<div class="modal-control control-close">Close</div>'));
		hideStrippedTextModal();
	});
}

function hideStrippedTextModal() {
	$(this).parent().siblings().empty();
	modal.addClass('hide');
}

function showDetailedDesc() {
	if ($(this).parent().hasClass('quadrant-description')) {
		modalHead.text($(this).parent().attr('data-quadrant-name')+' Factors');
	}
	else if ($(this).parent().hasClass('factor-content')) {
		modalHead.text($(this).parent().attr('data-factor-content'));
	}

	modalBody.text($(this).next('.detailed-desc').text());
	modal.removeClass('hide');
}

function showFactorDotDesc() {
	if ($(this).hasClass('estimate-dot')) {
		modalHead.text($(this).children('.dot-label').text());
	}
	else {
		modalHead.text('Your '+$(this).children('.dot-label').text()+' Risk');
	}

	modalBody.html($('.modal-feed-wrap [data-content="'+this.classList[1]+'"]').html());
	modal.removeClass('hide');
}

function showInfoIconDesc() {
	modalHead.text($(this).closest('.box.input-box').find('.capital-label').text());
	modalBody.html($('.modal-feed-wrap [data-content="'+$(this).attr('data-info')+'"]').html());
	modal.removeClass('hide');
}

function showDisclaimer() {
	modalHead.text('Disclaimer');
	modalBody.html($('.modal-feed-wrap [data-content="disclaimer"]').html());
	modal.removeClass('hide');
}

function showTileDetails() {
	modalHead.text($(this).attr('data-tile-info')+' Intake');

	var contentObj = $('.dietary-explanation[data-content="'+$(this).attr('data-tile-info')+'"]');

	if (contentObj.length > 0) {
		modalBody.html(contentObj[0].outerHTML);
	}

	modal.removeClass('hide');
}

function showClinicalConfirmModal() {
	modalHead.text('Confirm');
	modalBody.html($('[data-content="clinical-confirm"]').html());
	modalBody.next().html($('[data-content="clinical-confirm"] .modal-footer').html());
	modal.removeClass('hide');
}

/*-------------------------- Factor Content ------------------------*/
$('.quadrant-factors .factor').click(showSelectedFactor);

function showSelectedFactor() {
	var quadDesc = $('.quadrant-description'),
		factorContentWrap = $('.factor-contents-wrap'),
		factorContent = $('.factor-content[data-factor-content="' + $(this).attr('data-factor') + '"]');

	// showing selected tile 
	$(this).toggleClass('active').siblings().removeClass('active');
	// showing the content of the selected tile
	$('.factor-content').not(factorContent).addClass('hide');
	factorContent.toggleClass('hide');

	if ($(this).siblings().addBack().hasClass('active')) {
		quadDesc.addClass('hide');
		factorContentWrap.removeClass('hide');
	}
	else {
		quadDesc.removeClass('hide');
		factorContentWrap.addClass('hide');
	}
}

/*--------------------- Number Input Control -----------------------*/
$('.number-input-wrap .control-icon').click(tuneInputControl);

function tuneInputControl() {
	var inputControl = $(this).parent().find('input[type="text"]'),
		currentVal = parseInt(inputControl.val());

	if (isNaN(currentVal)) {
		inputControl.val(0); // Reset value to zero
	}
	else {
		if ($(this).hasClass('decrease') && currentVal>0) {
			inputControl.val(currentVal-1);
		}
		else if ($(this).hasClass('increase')) {
			inputControl.val(currentVal+1);
		}
	}	
}

/*--------------------- Slider Input Control -----------------------*/
// Set initial slider percentage
$('.slider-input-wrap').each(setInitialSlider);

// Adjust slider on click and drag
var sliderWidth, offsetLeft, ass;

$('.slider-input-wrap').on({
	'touchstart mousedown': function() {
		// Common stuff that doesn't need execution multiple times
		sliderWidth = $(this).width(),
		offsetLeft = this.offsetLeft;

		// Single click adjust
		adjustSliderDrag(this);

		// Drag adjust
		$(this).on({
			'touchmove mousemove': function() {
				adjustSliderDrag(this);
			}
		});
	},
	'touchend touchleave mouseup mouseleave': function() {
		$(this).unbind('touchmove mousemove');
		// console.log('Handler unbound');
	},
	'touchend mouseup': function() {
		// Shift to steps only when slider is clicked/dragged
		moveSliderToStep(this);
	}
});

function adjustSliderDrag(element) {
	var posX, percentage,
		eventType = event.type,
		elem = $(element);

	if (eventType=='touchstart' || eventType=='touchmove') { // for touch events
		posX = event.touches[0].pageX - offsetLeft;
	}
	else { //for mouse events
		posX = event.pageX - offsetLeft
	}
	
	// Fixing the offset of the slider handle
	posX = (posX < 0) ? 0 : posX;
	posX = (posX > sliderWidth) ? sliderWidth : posX;
	percentage = posX/sliderWidth*100;

	positionSlider(element, percentage);
}

function setInitialSlider() {
	var totalSteps = $(this).find('.slider-step').length || 2,
		stepAttr = $(this).children('.slider').attr('data-current-step'),
		currentStep = (stepAttr && parseInt(stepAttr)>0) ? parseInt(stepAttr) : 1,
		divisionWidth = 100 / (totalSteps-1);
		percentage = divisionWidth*(currentStep-1);

	if (currentStep <= totalSteps) {
		positionSlider(this, percentage);
	}
}

function moveSliderToStep(element) {
	var elem = $(element),
		totalSteps = elem.find('.slider-step').length,
		divisionWidth = 100 / (totalSteps-1),
		percentage = elem.find('input').val(),
		stepArray = [0, 100],
		betweenArray = [],
		nearestStep;

	for(var i=0; i<totalSteps-2; i++) {
		stepArray.splice((i+1), 0, (i+1)*divisionWidth);
	}
	// console.log(stepArray);

	for (var j=0; j<totalSteps; j++) {
		if (Math.abs(percentage-stepArray[j])<=divisionWidth) {
			// console.log('Step: '+stepArray[j]);
			betweenArray.push(stepArray[j]);
		}
	}

	if (Math.abs(percentage-betweenArray[0])<Math.abs(percentage-betweenArray[1])) {
		nearestStep = betweenArray[0];
	}
	else {
		nearestStep = betweenArray[1];
	}
	// console.log('Nearest Step: '+nearestStep);
	positionSlider(element, nearestStep);
}

function positionSlider(element, percentage) {
	var elem = $(element),
		perc = Math.round(percentage*100) / 100;

	elem.find('input').val(perc);

	elem.find('.slider-handle').css({
		left: perc + '%'
	});
	elem.find('.slider-fill').css({
		width: perc + '%'
	});

	// console.log('Slider handle positioned.');
}

/*--------------------- Toggle Input Control -----------------------*/
$('.toggle-button').on({
	click: toggleOption
});

function toggleOption() {
	$(this).toggleClass('active');
}

/*----------------------- Dropdown Control -------------------------*/
$('.dropdown').click(function() {
	$(this).find('.dropdown-options').toggleClass('hide').parent('.dropdown').toggleClass('dropdown-open');
});

$('.dropdown-options li').click(function() {
	$(this).parent().siblings('.selected-option').text($(this).text());
});

/*------------------------ Hamburger Menu --------------------------*/
$('.ham-menu').click(function() {
	$(this).children('.header-menu-wrap').fadeIn().children('.header-menu').slideDown();
});

$('.header-menu-wrap').click(function(event) {
	$(this).fadeOut().children('.header-menu').slideUp();
	event.stopPropagation();
}).children('.header-menu').click(function(event) {
	event.stopPropagation();
});


/*------------------------- Log Calendar ---------------------------*/
var today = new Date();

$('.calendar').each(generateCalendar);

function generateCalendar() {
	// Initially today's date
	var date = new Date();
	// Set date to 1st of month
	// date.setDate(1);

	// Set date back to nearest(last) Sunday
	date.setDate(date.getDate()-date.getDay());

	$(this).find('.calendar-column').each(function() {
		// Initially same as 'date'
		// var tempDate = new Date(date);

		// for (var i=0; i<4; i++) {
		// 	var	calDateElem = $('<div class="calendar-date">'+tempDate.getDate()+'</div>');

		// 	if (today.getDate()==tempDate.getDate()) {
		// 		calDateElem.addClass('selected-date');
		// 	}

		// 	$(this).append(calDateElem);
		// }

		var	calDateElem = $('<div class="calendar-date">'+date.getDate()+'</div>');

		if (today.getDate()==date.getDate()) {
			calDateElem.addClass('selected-date');
		}
		
		$(this).append(calDateElem);

		// Increase day by one
		date.setDate(date.getDate()+1);
	});
}



































/*--------------------------------------------------------------------
						  TEMPORARY GARBAGE
--------------------------------------------------------------------*/
$('.header-nav-option.back-button').click(function() {
	window.history.back();
});

if ($('.dark-btn, .green-btn').length==2) {
	var currentQuadrant = $('.header-title').text().split(' ')[0].toLowerCase(),
		footerNavigation = $('#footer'),
		prevBtn = footerNavigation.children().eq(0),
		nextBtn = footerNavigation.children().eq(1);

	// console.log(currentQuadrant);

	if (currentQuadrant == 'existential') {
		nextBtn.click(function(){openPage('lifestyle.html')});
	}
	else if (currentQuadrant == 'lifestyle') {
		prevBtn.click(function(){openPage('existential.html')});
		nextBtn.click(function(){openPage('symptoms.html')});
	}
	else if (currentQuadrant == 'symptoms') {
		prevBtn.click(function(){openPage('lifestyle.html')});
		nextBtn.click(function(){openPage('clinical.html')});
	}
	else if (currentQuadrant == 'clinical') {
		prevBtn.click(function(){openPage('symptoms.html')});
		// nextBtn.click(function(){openPage('radar.html')});
	}
}

function openPage(url) {
	window.open(url, '_self');
}

$('.factor[data-factor="diet"]').click(function() {openPage('diet-input.html')});
$('.factor[data-factor="symptoms"]').click(function() {openPage('symptoms-input.html')});
$('.warning-message-box').click(function() {openPage('warning.html')});
$('.mini-desc.recommendation-block').unbind('click').click(function(){
	if ($(this).attr('data-recommendation')=='exercise') {openPage('exercise-guidance.html')}
	else if ($(this).attr('data-recommendation')=='diet') {openPage('diet-guidance.html')}
});

// radar quadrant redirection
$('.radar-quadrant.quadrant-first').click(function(){openPage('symptoms.html')});
$('.radar-quadrant.quadrant-second').click(function(){openPage('lifestyle.html')});
$('.radar-quadrant.quadrant-third').click(function(){openPage('existential.html')});
$('.radar-quadrant.quadrant-fourth').click(function(){openPage('clinical.html')});


var animDur = 3000;
if ($('.entry-radar .initiate-radar').length > 0) {
	$('.modal-control.control-accept').click(function(event) {
		hideStrippedTextModal();
		$('.entry-radar .initiate-radar').fadeOut('400', function() {
			$('.entry-radar .radar-hand').css({
				'animation-name': 'rotate',
				'animation-iteration-count': 1,
				'animation-duration': (animDur/1000)+'s'
			});

			setTimeout(function() {
				$('.radar-quadrants-wrap .quadrant-third').removeClass('hide').css({				
					'padding-bottom': '50%',
					'cursor': 'pointer',
					'background': 'rgba(234, 233, 233, 0.8)',
					'opacity': 0,
					'animation': 'quadrant-pulsate 1.5s linear '+ 1/4*animDur/1000 +'s infinite'
				}).animate({
					'opacity': 1
				}, 1/8*animDur);

				$('.radar-quadrants-wrap .quadrant-third').on({
					'mouseover': function() {
						$(this).addClass('quadrant-arc');
					},
					'mouseleave': function() {
						$(this).removeClass('quadrant-arc');
					}
				});

			}, 3/4*animDur);

			setTimeout(function() {
				$('.radar-hand').animate({
					'opacity': 0
				}, 2000);
			}, 7/8*animDur);
		});
	});
}

$('.radio-input-wrap input[name="gender"]').change(function() {
	if ($(this).val()=='woman') {
		$(this).closest('.box').next('.toggle-control-block').removeClass('hide');
	}
	else {
		$(this).closest('.box').next('.toggle-control-block').addClass('hide');
	}
});

$('.footer-nav-item.nav-radar').click(function() {openPage('radar.html')});
$('.footer-nav-item.nav-scorecard').click(function() {openPage('scorecard.html')});
$('.footer-nav-item.nav-diet-activity').click(function() {openPage('log-diet-activity.html')});

$('.factors-data-import[data-quadrant-import="clinical"]').click(function(){openPage('login-charm.html')});

$('.dashboard-item.symptoms').click(function() {openPage('log-symptoms.html')});
$('.dashboard-item.clinical').click(function() {openPage('log-clinical.html')});
$('.dashboard-item.diet, .dashboard-item.activity').click(function() {openPage('log-diet-activity.html')});
$('.phr-login-form input[name="login"][type="button"]').click(function(){openPage('recommendation.html')});

